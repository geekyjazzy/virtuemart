<?php

namespace GingerPayments\Payment\Client;

final class ClientException extends \RuntimeException
{
}
